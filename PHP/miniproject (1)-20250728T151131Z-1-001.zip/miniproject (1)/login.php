<?php

include 'db.php';
session_start();

if ($_SERVER["REQUEST_METHOD"]==="POST"){
    $username=$conn->real_escape_string($_POST["username"]);
   $password=$_POST["password"];

   $check=$conn->query("SELECT * FROM users Where username='$username'");
   if($check->num_rows === 1){
    $user=$check->fetch_assoc();
    if(password_verify(password,$user['password'])){
        $_SESSION["user_id"]=$user["id"];
        $_SESSION["username"]=$user["username"];
        header("location: dashboard.php");

    }

    else{
        $msg="Invalid Password!";
    }

   
}

}
else{
    $msg="Invalid User";
}
?>



<div class="form-container">
    <form method="POST">
    <h2>Login</h2>
    <input type='text' name='username' placeholder='username' required ><br>
    <input type='password' name="password"
    placeholder="password" required><br>
    <button type="submit">Login</button>
    <p> Already have account? <a href="register.php">register here</a></p>

    <?php
    if(isset($msg)) echo "<p class='error'>$msg</p>";

    ?>

</form>
</div>